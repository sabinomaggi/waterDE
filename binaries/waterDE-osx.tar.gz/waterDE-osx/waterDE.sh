#!/bin/sh

APP="/Applications"
BIN="waterDE.app/Contents/MacOS/"
LIB="waterDE.app/Contents/Resources/lib"

export PATH="$APP/$BIN":$PATH
export DYLD_LIBRARY_PATH="$APP/$LIB":$DYLD_LIBRARY_PATH

# Run the executable application with its argument list
exec "waterDE" "$*"

